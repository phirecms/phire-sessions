<?php

namespace Sessions\Model;

use Phire\Model\AbstractModel;

class UserSession extends AbstractModel
{

}
