<?php

namespace Sessions\Controller\Users;

use Sessions\Model;
use Phire\Controller\AbstractController;
use Pop\Http\Response;
use Pop\Paginator\Paginator;

class IndexController extends AbstractController
{

    /**
     * Sessions action method
     *
     * @return void
     */
    public function sessions()
    {
        $session = new Model\UserSession();

        if ($session->hasPages($this->config->pagination)) {
            $limit = $this->config->pagination;
            $pages = new Paginator($session->getCount(), $limit);
            $pages->useInput(true);
        } else {
            $limit = null;
            $pages = null;
        }

        $this->prepareView('users/sessions.phtml');
        $this->view->title    = 'Users : Sessions';
        $this->view->pages    = $pages;
        $this->view->sessions = $session->getAll(
            $limit, $this->request->getQuery('page'), $this->request->getQuery('sort')
        );
        $this->send();
    }

    /**
     * Logins action method
     *
     * @param  int $id
     * @return void
     */
    public function logins($id)
    {
        $session = new Model\UserSession();
        if ($this->request->isPost()) {
            $session->clear($this->request->getPost());
            Response::redirect(BASE_PATH . APP_URI . '/users/logins/' . $id . '?removed=' . time());
            exit();
        } else {
            $session = new Model\UserSession();
            $session->getUserData($id);

            $this->prepareView('users/logins.phtml');
            $this->view->title           = 'Users : Logins';
            $this->view->logins          = $session->logins;
            $this->view->failed_attempts = $session->failed_attempts;
            $this->view->username        = $session->username;
            $this->view->user_id         = $session->user_id;
            $this->send();
        }
    }

    /**
     * Remove action method
     *
     * @return void
     */
    public function remove()
    {
        if ($this->request->isPost()) {
            $session = new Model\UserSession();
            $session->remove($this->request->getPost());
        }
        Response::redirect(BASE_PATH . APP_URI . '/users/sessions?removed=' . time());
    }

    /**
     * Prepare view
     *
     * @param  string $template
     * @return void
     */
    protected function prepareView($template)
    {
        $this->viewPath = __DIR__ . '/../../../view';
        parent::prepareView($template);
    }

}
