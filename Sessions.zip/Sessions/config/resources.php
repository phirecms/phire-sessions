<?php

return [
    'sessions' => [
        'index'
    ],
    'users-sessions' => [
        'index',
        'remove'
    ]
];