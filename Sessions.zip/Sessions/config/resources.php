<?php

return [
    'sessions' => [
        'index',
        'add',
        'edit',
        'remove'
    ],
    'users-sessions' => [
        'index',
        'logins',
        'remove'
    ]
];