<?php

return [
    'sessions' => [
        'index',
        'logins',
        'remove'
    ],
    'sessions-config' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];