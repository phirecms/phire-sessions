<?php

return [
    'sessions' => [
        'index',
        'logins',
        'json',
        'remove'
    ],
    'sessions-config' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];